package com.example.bytestock

data class printeritem (
    val image : Int,
    val printerName : String,
    val printerDetail : String

)